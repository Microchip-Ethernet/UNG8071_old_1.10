/*
 * Copyright 2015, Freescale Semiconductor
 *
 * SPDX-License-Identifier:	GPL-2.0+
 */

#ifndef _ASM_ARMV8_FSL_LAYERSCAPE_MMU_H_
#define _ASM_ARMV8_FSL_LAYERSCAPE_MMU_H_
#include <asm/arch-armv8/mmu.h>
#endif /* _ASM_ARMV8_FSL_LAYERSCAPE_MMU_H_ */
