/*
 * Copyright (C) 2011
 * Stefano Babic, DENX Software Engineering, <sbabic@denx.de>
 *
 * SPDX-License-Identifier:	GPL-2.0+
 */


#ifndef __ASM_ARCH_MX6_GPIO_H
#define __ASM_ARCH_MX6_GPIO_H

#include <asm/imx-common/gpio.h>

#endif	/* __ASM_ARCH_MX6_GPIO_H */
